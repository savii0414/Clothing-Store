package com.cs241.Group3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Group3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
